package com.davee.pdfyerimi

import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.davee.pdfyerimi.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var adapter: BookmarkAdapter

    private val openPdfLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            uri?.let { loadPdf(it) }
        }

    private val createDocxLauncher =
        registerForActivityResult(
            ActivityResultContracts.CreateDocument(
                "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
            )
        ) { uri ->
            uri?.let { saveDocx(it) }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        adapter = BookmarkAdapter(mutableListOf())
        binding.rvBookmarks.layoutManager = LinearLayoutManager(this)
        binding.rvBookmarks.adapter = adapter

        val touchHelper = ItemTouchHelper(object : ItemTouchHelper.SimpleCallback(
            ItemTouchHelper.UP or ItemTouchHelper.DOWN,
            ItemTouchHelper.LEFT
        ) {
            override fun onMove(
                recyclerView: RecyclerView,
                viewHolder: RecyclerView.ViewHolder,
                target: RecyclerView.ViewHolder
            ): Boolean {
                adapter.moveItem(viewHolder.bindingAdapterPosition, target.bindingAdapterPosition)
                return true
            }

            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {
                adapter.removeItem(viewHolder.bindingAdapterPosition)
            }
        })
        touchHelper.attachToRecyclerView(binding.rvBookmarks)

        binding.btnLoadPdf.setOnClickListener {
            openPdfLauncher.launch(arrayOf("application/pdf"))
        }

        binding.btnCreateWord.setOnClickListener {
            if (adapter.getItems().isEmpty()) {
                Toast.makeText(
                    this,
                    "Önce vurgulu/altı çizili metin içeren bir PDF yükleyin",
                    Toast.LENGTH_SHORT
                ).show()
            } else {
                createDocxLauncher.launch("YerImleri.docx")
            }
        }
    }

    private fun loadPdf(uri: Uri) {
        binding.tvStatus.text = "PDF taranıyor..."
        binding.btnLoadPdf.isEnabled = false

        Thread {
            try {
                val bookmarks = PdfHighlightExtractor.extract(this, uri)
                runOnUiThread {
                    adapter.setItems(bookmarks)
                    binding.btnLoadPdf.isEnabled = true
                    binding.tvStatus.text = if (bookmarks.isEmpty())
                        "Bu PDF'de vurgu/altı çizili metin bulunamadı"
                    else
                        "${bookmarks.size} yer imi bulundu. Sırayı değiştirmek için sürükleyin, silmek için sola kaydırın."
                }
            } catch (e: Exception) {
                runOnUiThread {
                    binding.btnLoadPdf.isEnabled = true
                    binding.tvStatus.text = "Hata: ${e.message}"
                }
            }
        }.start()
    }

    private fun saveDocx(uri: Uri) {
        binding.tvStatus.text = "Word dosyası oluşturuluyor..."
        Thread {
            try {
                DocxBuilder.build(this, adapter.getItems(), uri)
                runOnUiThread {
                    binding.tvStatus.text = "Word dosyası indirildi"
                    Toast.makeText(this, "Word dosyası oluşturuldu", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    binding.tvStatus.text = "Hata: ${e.message}"
                    Toast.makeText(this, "Hata: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }.start()
    }
}
