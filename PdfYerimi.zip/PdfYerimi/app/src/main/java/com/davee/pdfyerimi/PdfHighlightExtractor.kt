package com.davee.pdfyerimi

import android.content.Context
import android.graphics.RectF
import android.net.Uri
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.interactive.annotation.PDAnnotationTextMarkup
import com.tom_roush.pdfbox.text.PDFTextStripperByArea
import java.awt.geom.Rectangle2D

/**
 * PDF dosyasındaki gerçek "Highlight" (vurgu) ve "Underline" (altı çizili)
 * annotasyonlarını bulur, bu annotasyonların kapladığı alandaki metni
 * çıkarır ve sayfa numarasıyla birlikte bir Bookmark listesi döndürür.
 */
object PdfHighlightExtractor {

    private const val SUBTYPE_HIGHLIGHT = "Highlight"
    private const val SUBTYPE_UNDERLINE = "Underline"

    fun extract(context: Context, uri: Uri): List<Bookmark> {
        val bookmarks = mutableListOf<Bookmark>()

        val inputStream = context.contentResolver.openInputStream(uri)
            ?: return bookmarks

        inputStream.use { stream ->
            val document = PDDocument.load(stream)
            try {
                for (pageIndex in 0 until document.numberOfPages) {
                    val page = document.getPage(pageIndex)
                    val pageHeight = page.mediaBox.height

                    val annotations = page.annotations ?: continue

                    for (annotation in annotations) {
                        val subtype = annotation.subtype
                        if (subtype != SUBTYPE_HIGHLIGHT && subtype != SUBTYPE_UNDERLINE) continue

                        val markup = annotation as? PDAnnotationTextMarkup ?: continue
                        val quadPoints = markup.quadPoints ?: continue
                        if (quadPoints.isEmpty()) continue

                        val rects = rectanglesFromQuadPoints(quadPoints, pageHeight)
                        if (rects.isEmpty()) continue

                        val stripper = PDFTextStripperByArea()
                        stripper.sortByPosition = true

                        rects.forEachIndexed { idx, r ->
                            val w = if (r.width() > 0f) r.width() else 1f
                            val h = if (r.height() > 0f) r.height() else 1f
                            stripper.addRegion("bolge$idx", Rectangle2D.Float(r.left, r.top, w, h))
                        }

                        stripper.extractRegions(page)

                        val text = rects.indices
                            .joinToString(" ") { stripper.getTextForRegion("bolge$it")?.trim().orEmpty() }
                            .replace(Regex("\\s+"), " ")
                            .trim()

                        if (text.isNotEmpty()) {
                            val type = if (subtype == SUBTYPE_HIGHLIGHT) "Vurgu" else "Alt Çizgi"
                            bookmarks.add(Bookmark(pageIndex + 1, text, type))
                        }
                    }
                }
            } finally {
                document.close()
            }
        }

        return bookmarks
    }

    /**
     * PDF QuadPoints dizisini (her biri 8 float, PDF koordinat sistemi - orijin sol alt)
     * ekranda/PDFTextStripperByArea'da kullanılan sol üst orijinli dikdörtgenlere çevirir.
     */
    private fun rectanglesFromQuadPoints(quadPoints: FloatArray, pageHeight: Float): List<RectF> {
        val rects = mutableListOf<RectF>()
        var i = 0
        while (i + 7 < quadPoints.size) {
            val xs = floatArrayOf(quadPoints[i], quadPoints[i + 2], quadPoints[i + 4], quadPoints[i + 6])
            val ys = floatArrayOf(quadPoints[i + 1], quadPoints[i + 3], quadPoints[i + 5], quadPoints[i + 7])

            val xMin = xs.min()
            val xMax = xs.max()
            val yMin = ys.min()
            val yMax = ys.max()

            val top = pageHeight - yMax
            val height = yMax - yMin

            rects.add(RectF(xMin, top, xMax, top + height))
            i += 8
        }
        return rects
    }
}
