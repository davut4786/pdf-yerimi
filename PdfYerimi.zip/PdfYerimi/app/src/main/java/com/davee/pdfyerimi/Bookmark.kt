package com.davee.pdfyerimi

/**
 * PDF içinde tespit edilen bir vurgu/altı çizili metin parçası.
 */
data class Bookmark(
    val pageNumber: Int,
    var text: String,
    val type: String // "Vurgu" (highlight) ya da "Alt Çizgi" (underline)
)
