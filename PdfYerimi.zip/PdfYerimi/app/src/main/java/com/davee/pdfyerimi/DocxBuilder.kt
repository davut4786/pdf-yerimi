package com.davee.pdfyerimi

import android.content.Context
import android.net.Uri
import java.io.BufferedOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * Apache POI gibi ağır kütüphanelere ihtiyaç duymadan, geçerli bir .docx
 * (OOXML) dosyasını doğrudan zip + xml olarak üretir. Word, LibreOffice ve
 * Google Dokümanlar bu formatı sorunsuz açar.
 */
object DocxBuilder {

    fun build(context: Context, bookmarks: List<Bookmark>, outputUri: Uri) {
        val outputStream = context.contentResolver.openOutputStream(outputUri)
            ?: throw IllegalStateException("Çıkış dosyası açılamadı")

        ZipOutputStream(BufferedOutputStream(outputStream)).use { zip ->
            writeEntry(zip, "[Content_Types].xml", contentTypesXml())
            writeEntry(zip, "_rels/.rels", relsXml())
            writeEntry(zip, "word/document.xml", documentXml(bookmarks))
        }
    }

    private fun writeEntry(zip: ZipOutputStream, name: String, content: String) {
        zip.putNextEntry(ZipEntry(name))
        zip.write(content.toByteArray(Charsets.UTF_8))
        zip.closeEntry()
    }

    private fun contentTypesXml() = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
</Types>"""

    private fun relsXml() = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
</Relationships>"""

    private fun documentXml(bookmarks: List<Bookmark>): String {
        val body = StringBuilder()

        body.append(
            "<w:p><w:pPr><w:jc w:val=\"center\"/></w:pPr><w:r><w:rPr><w:b/><w:sz w:val=\"32\"/></w:rPr>" +
                "<w:t>Yer İmleri</w:t></w:r></w:p>"
        )

        bookmarks.forEachIndexed { index, bookmark ->
            val baslik = "${index + 1}. Sayfa ${bookmark.pageNumber} (${bookmark.type})"
            body.append(
                "<w:p><w:pPr><w:spacing w:before=\"240\" w:after=\"60\"/></w:pPr>" +
                    "<w:r><w:rPr><w:b/><w:color w:val=\"1F4E79\"/></w:rPr>" +
                    "<w:t>${escape(baslik)}</w:t></w:r></w:p>"
            )
            body.append(
                "<w:p><w:pPr><w:spacing w:after=\"120\"/></w:pPr>" +
                    "<w:r><w:t xml:space=\"preserve\">${escape(bookmark.text)}</w:t></w:r></w:p>"
            )
        }

        return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
<w:body>
$body
<w:sectPr>
<w:pgSz w:w="11906" w:h="16838"/>
<w:pgMar w:top="1417" w:right="1417" w:bottom="1417" w:left="1417"/>
</w:sectPr>
</w:body>
</w:document>"""
    }

    private fun escape(text: String): String {
        return text
            .replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace("\"", "&quot;")
            .replace("'", "&apos;")
    }
}
