package com.davee.pdfyerimi

import android.app.Application
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader

class PdfYerimiApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // PDFBox-Android'in fontlar gibi kaynakları yükleyebilmesi için gereklidir.
        PDFBoxResourceLoader.init(applicationContext)
    }
}
